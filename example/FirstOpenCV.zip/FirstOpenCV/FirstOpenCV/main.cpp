#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"


using namespace cv;
using namespace std;

int main(int argc, char *argv[]) {
//    char path[] = "/Users/morris/Documents/lena.jpg";
    char path[] = "lena.jpg";
    
    Mat image, gray_image;
    
    image = imread(path, 1);
    cvtColor(image, gray_image, CV_RGB2GRAY);
    
    imwrite("lena.jpg", gray_image);
    namedWindow("Lena", CV_WINDOW_AUTOSIZE);
    namedWindow("Gray image", CV_WINDOW_AUTOSIZE);
    
//    imshow(path, image);
    imshow("Gray image", gray_image);
    
    waitKey(0);
    
    return 0;
}

